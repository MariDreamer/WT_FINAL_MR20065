<?php
    return [ 'span' => "There are no posts on Speak'N'Post yet! Be first to voicepost!",
    'span1'=> "You have no posts on Speak'N'Post yet! Let's begin!",
    'div'=> "Login",
    'label' => 'E-Mail Address',
    'label1' => 'Password',
    'label2' => 'Remember Me',
    'button' => 'Login',
    'a' => 'Forgot Your Password?',
    'div1'=> 'Register',
    'label3' => 'Name',
    'label4' => 'E-Mail Address',
    'label5' => 'Password',
    'label6' => 'Confirm Password',
    'button1' => 'Register']
?>

