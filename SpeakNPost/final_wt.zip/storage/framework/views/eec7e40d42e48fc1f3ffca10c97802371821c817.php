<?php $__env->startSection('content'); ?>
<div class="this">
    <?php echo csrf_field(); ?>
    <?php if(count($voiceposts)==0): ?>
    <div class="nada" style="height: 100vh; vertical-align: middle;"> <span class="boo" style="display: inline-block; vertical-align: middle; margin-top: 50vh;"><?php echo e(__('lang.span')); ?></span></div>
    <?php else: ?>
    <p> Boo normal!</p>
    <div >
        <?php $__currentLoopData = $voiceposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voicepost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
                <a><?php echo e($voicepost->date); ?> <?php echo e($voicepost->url_vp); ?> <?php echo e($voicepost->t_name); ?> </a>
            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SpeakNPost\resources\views/homepage.blade.php ENDPATH**/ ?>